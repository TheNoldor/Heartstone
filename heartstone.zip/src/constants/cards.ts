export const CARD_IMG_URL =
  "https://images.blz-contentstack.com/v3/assets/bltc965041283bac56c/blt7052603b034d2fab/620d451c9485354f9b4607e6/23.0_cardback.webp";

  export const MANA_COST_IMG_URL = "https://u.to/zzEZHA";