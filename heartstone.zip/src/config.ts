export const BASE_URL: string = process.env.REACT_APP_BASE_URL || "";
export const API_HOST: string = process.env.REACT_APP_API_HOST || "";
export const API_KEY: string = process.env.REACT_APP_API_KEY || "";
