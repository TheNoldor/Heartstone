import CardDetails from "../../CardDetails/index";
import { ICard } from "../../../redux/reducers/reposReducer";

import styles from "./styles.module.scss";

const CardItem = ({ card }: ICard) => {
  //const img1 = card.img;

  return (
    <div className={styles.card} onClick={() => CardDetails()}>
      <img className="CardImg" alt="" src={card.img} />
    </div>
  );
};

export default CardItem;
